=== Media test ===
Tags: media, folder
Requires at least: 3.5.1
Tested up to: 4.4
Stable tag: 3.3.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP media Folder is a WordPress plugin that enhance the WordPress media manager by adding a folder manager inside.

== Description ==

If you were struggling with files and you didn't know how to organize them... 
It's over! With WP Media Folder life is easy, you can manage files, images from the native Wordpress media manager. 
YES, It's true! We did in the media manager of WordPress a file manager where you can drag and drop images and files so easely. 
I can not tell more just watch our demo and please try it to make your own idea.

Stop searching for an image through thousand of media, just navigate like you do on your desktop file manager.

= Changelog = 

{{changelog}}