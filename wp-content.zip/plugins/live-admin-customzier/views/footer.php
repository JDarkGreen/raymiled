</div>

<script>
var site_url = '<?php echo site_url(); ?>';
</script>