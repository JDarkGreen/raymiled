<div id="adminbar" class="tab hidden tab-table">
<div class="postbox">
    <div class="inside">
    <table class="form-table">
		<tbody>
			<tr>
				<th>Submenu Background Colour</th>
				<td>
					<input type="text" placeholder="Pick A Colour" name="colors[menu-submenu-background-alt]" data-color="yes" value="<?php echo $this->scss_val('menu-submenu-background-alt'); ?>" class="lacc_colorpicker">
				</td>
			</tr>

			<tr>
				<th>Avatar Frame Colour</th>
				<td>
					<input type="text" placeholder="Pick A Colour" name="colors[adminbar-avatar-frame]" data-color="yes" value="<?php echo $this->scss_val('adminbar-avatar-frame'); ?>" class="lacc_colorpicker">
				</td>
			</tr>

			<tr>
				<th>Textbox Background Colour</th>
				<td>
					<input type="text" placeholder="Pick A Colour" name="colors[adminbar-input-background]" data-color="yes" value="<?php echo $this->scss_val('adminbar-input-background'); ?>" class="lacc_colorpicker">
				</td>
			</tr>
		</tbody>
	</table>
    </div></div>
</div>

